// ========================================
// MENÚ HAMBURGUESA - MÍNIMO FUNCIONAL
// ========================================
document.addEventListener("DOMContentLoaded", function () {
  const menuBtn = document.querySelector(".menu-mobile button");
  const menuDesktop = document.querySelector(".menu-desktop");

  menuBtn.addEventListener("click", function (e) {
    e.stopPropagation();
    menuDesktop.classList.toggle("menu-open");
  });

  // Cerrar al clic fuera
  document.addEventListener("click", function () {
    menuDesktop.classList.remove("menu-open");
  });

  // ========================================
  // BOTÓN VOLVER ARRIBA - INTERACTIVIDAD EXTRA
  // ========================================
  const volverArriba = document.createElement("button");
  volverArriba.innerHTML = "↑";
  volverArriba.className = "btn-volver-arriba";
  volverArriba.setAttribute("aria-label", "Volver al inicio");
  volverArriba.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
        border: none;
        border-radius: 50%;
        background: var(--color-deco);
        color: white;
        font-size: 1.2rem;
        cursor: pointer;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s;
        z-index: 99;
    `;

  document.body.appendChild(volverArriba);

  // Mostrar/ocultar según scroll
  window.addEventListener("scroll", function () {
    if (window.scrollY > 300) {
      volverArriba.style.opacity = "1";
      volverArriba.style.visibility = "visible";
    } else {
      volverArriba.style.opacity = "0";
      volverArriba.style.visibility = "hidden";
    }
  });

  // Scroll suave
  volverArriba.addEventListener("click", function () {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  });
});

// MODAL GALERÍA - MÍNIMO
document.addEventListener("click", (e) => {
  if (e.target.closest(".galeria-figure")) {
    // ← CAMBIO AQUÍ
    const img = e.target
      .closest(".galeria-figure")
      .querySelector(".galeria-img");
    const modal = e.target.closest(".galeria").querySelector(".modal-galeria");
    modal.querySelector(".modal-img").src = img.src;
    modal.querySelector(".modal-img").alt = img.alt;
    modal.classList.add("mostrar");
    document.body.style.overflow = "hidden";
  }
  if (
    e.target.classList.contains("modal-cerrar") ||
    e.target.classList.contains("modal-galeria") ||
    e.target.classList.contains("modal-img")
  ) {
    e.target.closest(".modal-galeria").classList.remove("mostrar");
    document.body.style.overflow = "";
  }
});
